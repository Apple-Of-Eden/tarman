/*
 * Implementation file for simple MapReduce framework.  Fill in the functions
 * and definitions in this file to complete the assignment.
 *
 * Place all of your implementation code in this file.  You are encouraged to
 * create helper functions wherever it is necessary or will make your code
 * clearer.  For these functions, you should follow the practice of declaring
 * them "static" and not including them in the header file (which should only be
 * used for the *public-facing* API.
 */


/* Header includes */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "mapreduce.h"


/* Size of shared memory buffers */
#define MR_BUFFER_SIZE 1024

struct reducer_args {
	struct map_reduce *mr;
	int outfd;
	int nmaps;
};

struct mapper_args {
	struct map_reduce *mr;
	int id;                          // unique mapper ID from 0 to (num_of_threads - 1)
	int nmaps;                       // total number of mapper threads	
};

/* Allocates and initializes an instance of the MapReduce framework */
struct map_reduce *
mr_create(map_fn map, reduce_fn reduce, int nmaps)
{
	struct map_reduce *mr = malloc(sizeof(*mr));
    if(mr == NULL) {
        return NULL;
    }

    mr->num_of_threads = nmaps;
    mr->usr_map_fn = map;
    mr->usr_reduce_fn = reduce;
    mr->threadFailed = 0;         // equals -1 otherwise

	if(reduce == NULL) {
		mr->amClient = 0;    // running on client (mapper threads)
	} else {
		mr->amClient = 1;    // running on server (reducer thread)
	}

    
	mr->mapper_threads = malloc(nmaps* sizeof(*(mr->mapper_threads)));
	if(mr->mapper_threads == NULL) {
		return NULL;
	}
	
	mr->infd = malloc(nmaps* sizeof(*(mr->infd)));
	if(mr->infd == NULL) {
		return NULL;
	}

	mr->reducerArgs = (struct reducer_args *) malloc(sizeof(struct reducer_args));
	if(mr->reducerArgs == NULL) {
		return NULL;
	}

	mr->mapperArgs = malloc(nmaps*sizeof(struct mapper_args *));
	if(mr->mapperArgs == NULL) {
		return NULL;
	}
	
	mr->mappers_socketfd = malloc(nmaps*sizeof(*(mr->mappers_socketfd)));
	if(mr->mappers_socketfd == NULL) {
		return NULL;
	}

	mr->acceptedfd = malloc(nmaps*sizeof(*(mr->acceptedfd)));
	if(mr->acceptedfd == NULL) {
		return NULL;
	}

	return mr;
}

/* Destroys and cleans up an existing instance of the MapReduce framework */
void
mr_destroy(struct map_reduce *mr)
{
	free(mr->mapper_threads);
	free(mr->infd);
	free(mr->reducerArgs);      
	free(mr->mapperArgs);       
	free(mr->mappers_socketfd);
	free(mr->acceptedfd);
	free(mr);
}

static void *  mapper_thread_enter(void * arg) {
	struct mapper_args * m_args = (struct mapper_args*) arg; 
	
	if((m_args->mr->usr_map_fn)(m_args->mr, m_args->mr->infd[m_args->id], m_args->id, m_args->nmaps)) {
		fprintf(stderr, "mapper function returned error\n");
		m_args->mr->threadFailed = -1;
		
		free(m_args);
		return (void *) -1;
	}

	free(m_args);      
	return (void *) 0;
}

static void * reducer_thread_enter(void * arg) {
	struct reducer_args * r_args = (struct reducer_args *) arg;	

	// Accept each incoming mapper connection(s)
	int i;
	for(i = 0; i < r_args->mr->num_of_threads; i++) {
		r_args->mr->acceptedfd[i] = accept(r_args->mr->reducer_socketfd, (struct sockaddr*) NULL, NULL); // NULL as we don't need to store client's address
		if(r_args->mr->acceptedfd[i] < 0) {
			perror("Error with reducer accepting connection");
			return (void *) -1;
		}	
	}	

	if((r_args->mr->usr_reduce_fn)(r_args->mr,r_args->mr->outfd, r_args->nmaps)) {
		fprintf(stderr, "reducer function returned error\n");
		r_args->mr->threadFailed = -1;
		return (void *) -1;
	}

	return (void *) 0;
}


/* Begins a multithreaded MapReduce operation */
int
mr_start(struct map_reduce *mr, const char *path, const char *ip, uint16_t port)
{
	void * (*mapper_fctn_ptr)(void * arg);
	mapper_fctn_ptr = &mapper_thread_enter;
	
	void * (*reducer_fctn_ptr) (void * arg);
	reducer_fctn_ptr = &reducer_thread_enter;

	int i,j;

	struct sockaddr_in serv_addr;
	

	if(mr->amClient == 0) {   // if is a client
		// Set up server address struct (same for all mappers)
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(port);
		serv_addr.sin_addr.s_addr = inet_addr(ip);

		// Create mapper threads
		for(i=0;i < mr->num_of_threads;i++) {
			
			// Create socket
			mr->mappers_socketfd[i] = socket(AF_INET, SOCK_STREAM, 0);
			if(mr->mappers_socketfd[i] < 0) {
				perror("Error opening mapper socket\n");
				return -1;
			}
			
			// Connect to server
			if(connect(mr->mappers_socketfd[i], (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
				perror("Error with mapper connecting to server");
				return -1;
			}


			// Create thread
			mr->mapperArgs[i] = malloc(sizeof(struct mapper_args));
			if(mr->mapperArgs[i] == NULL) {
				return -1;
			}
			((struct mapper_args *)(mr->mapperArgs[i]))->mr = mr;
			((struct mapper_args *)(mr->mapperArgs[i]))->id = i;
			((struct mapper_args *)(mr->mapperArgs[i]))->nmaps = mr->num_of_threads;
			mr->infd[i] = open(path, O_RDONLY);
			if(mr->infd[i] == -1) {
				for(j = 0; j<=i;j++) {
					free(mr->mapperArgs[j]);
				}	
				return -1;
			}
			if(pthread_create(&(mr->mapper_threads[i]), NULL, mapper_fctn_ptr, (void *)mr->mapperArgs[i])) {
				fprintf(stderr, "Error while creating mapper threads\n");
				return -1;
			}
		}

	}else {
		// Open up a socket for the reducer
		mr->reducer_socketfd = socket(AF_INET, SOCK_STREAM, 0);
		if (mr->reducer_socketfd < 0) {
			perror("Error creating reducer socket.");
			return -1;
		}
	
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(port);
		serv_addr.sin_addr.s_addr = inet_addr(ip);

		// Bind socket
		if(bind(mr->reducer_socketfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
			perror("Error binding reducer socket.");		
			close(mr->reducer_socketfd);
			return -1;
		}		
		
		// Listen
		listen(mr->reducer_socketfd, mr->num_of_threads);
	
		// Create reducer thread
		((struct reducer_args *)(mr->reducerArgs))->mr = mr;
		mr->outfd = open(path, O_WRONLY | O_CREAT | O_TRUNC);
		((struct reducer_args *)(mr->reducerArgs))->nmaps = mr->num_of_threads;
		if(pthread_create(&(mr->reducer_thread), NULL, reducer_fctn_ptr, (void *)mr->reducerArgs)) {
			fprintf(stderr, "Error while creating reducer thread\n");
			close(mr->reducer_socketfd);
			close(mr->outfd);
			return -1;
		}
	}
	
	return 0;
}

/* Blocks until the entire MapReduce operation is complete */
int
mr_finish(struct map_reduce *mr)
{
	int i;
	
	if(mr->amClient == 0) {   // if is a mapper client
		// Wait for threads	
		for(i = 0; i < mr->num_of_threads; i++) {
			if(pthread_join(mr->mapper_threads[i], NULL) != 0) { // THIS MAY BE BUSY WAITING SO MAYBE CHANGE	
				return -1;
			}
		}

		// Close mapper sockets
		for(i=0; i < mr->num_of_threads; i++) {
			close(mr->mappers_socketfd[i]);		
		}

		// Close files
		for(i=0; i < mr->num_of_threads; i++) {
			close(mr->infd[i]);
		}
	} else {
		// Wait for thread
		if(pthread_join(mr->reducer_thread, NULL) != 0) {
			return -1;
		}   

		// Close reducer sockets
		for(i = 0; i < mr->num_of_threads; i++) {
			close(mr->acceptedfd[i]);
		}
		close(mr->reducer_socketfd);

		// Close files
		close(mr->outfd);
	}

		
	if(mr->threadFailed == -1) {
		return -1;
	} else {
		return 0;
	}
}

/* Called by the Map function each time it produces a key-value pair */
int
mr_produce(struct map_reduce *mr, int id, const struct kvpair *kv)
{
	// Send kv->keysz
	if(send(mr->mappers_socketfd[id], &(kv->keysz), sizeof(kv->keysz), 0) < 0) {
		perror("Error sending kv->keysz.");
		return -1;
	}			

	// Send kv->key
	if(send(mr->mappers_socketfd[id], kv->key, kv->keysz, 0) < 0) {
		perror("Error sending kv->key.");
		return -1;
	}			

	// Send kv->valuesz
	if(send(mr->mappers_socketfd[id], &(kv->valuesz), sizeof(kv->valuesz), 0) < 0) {
		perror("Error sending kv->valuesz.");
		return -1;
	}			

	// Send kv->value
	if(send(mr->mappers_socketfd[id], kv->value, kv->valuesz, 0) < 0) {
		perror("Error sending kv->value.");
		return -1;
	}			

	return 1;
}

/* Called by the Reduce function to consume a key-value pair */
int
mr_consume(struct map_reduce *mr, int id, struct kvpair *kv)
{
	unsigned char buffer[128];
	int bytesRead;
	
	// Read kv->keysz
	bytesRead = recv(mr->acceptedfd[id], buffer, sizeof(kv->keysz), 0); // This blocks until incoming bytes or connection close

	if(bytesRead == 0) {   // finished reading in 
		return 0;			
	}
	if(bytesRead < 0){    // some error reading in			perror("Error reading in bytes");
		perror("Error reading in bytes");
		return -1;
	}
	memcpy(&(kv->keysz), &(buffer[0]), sizeof(kv->keysz));


	// Read kv->key	
	bytesRead = recv(mr->acceptedfd[id], buffer, kv->keysz, 0); // This blocks until incoming bytes or connection close

	if(bytesRead == 0) {   // finished reading in 
		return 0;			
	}
	if(bytesRead < 0){    // some error reading in
		perror("Error reading in bytes");
		return -1;
	}
	memcpy(kv->key, &(buffer[0]), kv->keysz);
	

	// Read kv->valuesz
	bytesRead = recv(mr->acceptedfd[id], buffer, sizeof(kv->valuesz), 0); // This blocks until incoming bytes or connection close

	if(bytesRead == 0) {   // finished reading in 
		return 0;			
	}
	if(bytesRead < 0){    // some error reading in
		perror("Error reading in bytes");
		return -1;
	}
	memcpy(&(kv->valuesz), &(buffer[0]), sizeof(kv->valuesz));
	

	// Read kv->value
	bytesRead = recv(mr->acceptedfd[id], buffer, kv->valuesz, 0); // This blocks until incoming bytes or connection close
	if(bytesRead == 0) {   // finished reading in 
		return 0;				
	}
	if(bytesRead < 0){    // some error reading in
		perror("Error reading in bytes");
		return -1;
	}
	memcpy(kv->value, &(buffer[0]), kv->valuesz);

	return 1;
}
