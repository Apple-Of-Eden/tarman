/*
 * Implementation file for simple MapReduce framework.  Fill in the functions
 * and definitions in this file to complete the assignment.
 *
 * Place all of your implementation code in this file.  You are encouraged to
 * create helper functions wherever it is necessary or will make your code
 * clearer.  For these functions, you should follow the practice of declaring
 * them "static" and not including them in the header file (which should only be
 * used for the *public-facing* API.
 */


/* Header includes */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include "mapreduce.h"


/* Size of shared memory buffers */
#define MR_BUFFER_SIZE 1024

struct reducer_args {
	struct map_reduce *mr;
	int outfd;
	int nmaps;
};

struct mapper_args {
	struct map_reduce *mr;
	int id;                          // unique mapper ID from 0 to (num_of_threads - 1)
	int nmaps;                       // total number of mapper threads	
};


/* Allocates and initializes an instance of the MapReduce framework */
struct map_reduce *
mr_create(map_fn map, reduce_fn reduce, int threads)
{
	struct map_reduce *mr = malloc(sizeof(*mr));
	if(mr == NULL) {
		return NULL;
	}
	
	mr->num_of_threads = threads;
	mr->usr_map_fn = map;
	mr->usr_reduce_fn = reduce;
	mr->threadFailed = 0;         // equals -1 otherwise

	
	mr->filledBuffer = calloc(threads, sizeof(*(mr->filledBuffer)));

	mr->buffers = calloc(threads, sizeof(*(mr->buffers)));
	if(mr->buffers == NULL) {
		return NULL;
	}	

	mr->bytesInBuffers = calloc(threads, sizeof(*(mr->bytesInBuffers)));
	if(mr->bytesInBuffers == NULL) {
		return NULL;
	}	


	mr->bufferOffsets = calloc(threads, sizeof(*(mr->bufferOffsets)));
	if(mr->bufferOffsets == NULL) {
		return NULL;
	}
	
	int i;
	for(i = 0; i < threads; i++) {
		mr->buffers[i] = calloc(MR_BUFFER_SIZE, sizeof(*(mr->buffers[i])));
		if(mr->buffers[i] == NULL) {
			return NULL;
		}
	}

	mr->bufferFull_c = malloc(threads*sizeof(*(mr->bufferFull_c)));
	if(mr->bufferFull_c == NULL) {
		return NULL;
	}

	for(i = 0; i < threads; i++) {
		pthread_cond_init(&(mr->bufferFull_c[i]), NULL);
	}

	mr->bufferFullLock = malloc(threads*sizeof(*(mr->bufferFullLock)));
	if(mr->bufferFullLock == NULL) {
		return NULL;
	}

	mr->extractOffsets = calloc(threads, sizeof(*(mr->extractOffsets)));
	if(mr->extractOffsets == NULL) {
		return NULL;
	}

	mr->rwBufLock = malloc(threads*sizeof(*(mr->rwBufLock)));
	if(mr->rwBufLock == NULL) {
		return NULL;
	}
	for(i = 0; i < threads; i++) {
		pthread_mutex_init(&(mr->rwBufLock[i]),NULL);   
	}
    
	mr->mapper_threads = malloc(threads * sizeof(*(mr->mapper_threads)));
	if(mr->mapper_threads == NULL) {
		return NULL;
	}
	
	mr->infd = malloc(threads* sizeof(*(mr->infd)));
	if(mr->infd == NULL) {
		return NULL;
	}

	mr->reducerArgs = (struct reducer_args *) malloc(sizeof(struct reducer_args));
	if(mr->reducerArgs == NULL) {
		return NULL;
	}

	mr->mapperArgs = malloc(threads*sizeof(struct mapper_args *));
	if(mr->mapperArgs == NULL) {
		return NULL;
	}

	mr->mapperFinished = calloc(threads, sizeof(*(mr->mapperFinished)));
	if(mr->mapperFinished == NULL) {
		return NULL;
	}

	mr->mapperFinishedLock = malloc(threads*sizeof(*(mr->mapperFinishedLock)));
	if(mr->mapperFinishedLock == NULL) {
		return NULL;
	}
	for(i = 0; i < threads; i++) {
		pthread_mutex_init(&(mr->mapperFinishedLock[i]),NULL);   
	}
	
	return mr;
}

/* Destroys and cleans up an existing instance of the MapReduce framework */
void
mr_destroy(struct map_reduce *mr)
{
	int i;
	
	for(i = 0;i < mr->num_of_threads; i++) {
		free(mr->buffers[i]);
	}
	
	free(mr->buffers);
	free(mr->bytesInBuffers);
	free(mr->bufferOffsets);
	free(mr->bufferFull_c);
	free(mr->bufferFullLock);
	free(mr->rwBufLock);
	free(mr->extractOffsets);
	free(mr->mapper_threads);
	free(mr->infd);
	free(mr->reducerArgs);      
	free(mr->mapperArgs);       
	free(mr->mapperFinished);
	free(mr->mapperFinishedLock);
	free(mr->filledBuffer);
	free(mr);
}

 


static void *  mapper_thread_enter(void * arg) {
	struct mapper_args * m_args = (struct mapper_args*) arg; 
	
	if((m_args->mr->usr_map_fn)(m_args->mr, m_args->mr->infd[m_args->id], m_args->id, m_args->nmaps)) {
		fprintf(stderr, "mapper function returned error\n");
		m_args->mr->threadFailed = -1;
		
		// Set shared varialbe saying the thread finished
		pthread_mutex_lock(&(m_args->mr->mapperFinishedLock[m_args->id]));	
		m_args->mr->mapperFinished[m_args->id] = 1; 
		pthread_mutex_unlock(&(m_args->mr->mapperFinishedLock[m_args->id]));	

		free(m_args);
		return (void *) -1;
	}

	// Set shared variable saying the thread finished
	pthread_mutex_lock(&(m_args->mr->mapperFinishedLock[m_args->id]));	
	m_args->mr->mapperFinished[m_args->id] = 1; 
	pthread_mutex_unlock(&(m_args->mr->mapperFinishedLock[m_args->id]));	

	free(m_args);      
	return (void *) 0;
}

static void * reducer_thread_enter(void * arg) {
	struct reducer_args * r_args = (struct reducer_args *) arg;	
	
	if((r_args->mr->usr_reduce_fn)(r_args->mr,r_args->mr->outfd, r_args->nmaps)) {
		fprintf(stderr, "reducer function returned error\n");
		r_args->mr->threadFailed = -1;
		return (void *) -1;
	}

	return (void *) 0;
}


/* Begins a multithreaded MapReduce operation */
int
mr_start(struct map_reduce *mr, const char *inpath, const char *outpath)
{
	void * (*mapper_fctn_ptr)(void * arg);
	mapper_fctn_ptr = &mapper_thread_enter;
	
	void * (*reducer_fctn_ptr) (void * arg);
	reducer_fctn_ptr = &reducer_thread_enter;

	int i,j;
	
	// Create mapper threads
	for(i=0;i < mr->num_of_threads;i++) {
		mr->mapperArgs[i] = malloc(sizeof(struct mapper_args));
		if(mr->mapperArgs[i] == NULL) {
			return -1;
		}
		((struct mapper_args *)(mr->mapperArgs[i]))->mr = mr;
		((struct mapper_args *)(mr->mapperArgs[i]))->id = i;
		((struct mapper_args *)(mr->mapperArgs[i]))->nmaps = mr->num_of_threads;
		mr->infd[i] = open(inpath, O_RDONLY);
		if(mr->infd[i] == -1) {
			for(j = 0; j<=i;j++) {
				free(mr->mapperArgs[j]);
			}	
			return -1;
		}
		if(pthread_create(&(mr->mapper_threads[i]), NULL, mapper_fctn_ptr, (void *)mr->mapperArgs[i])) {
			fprintf(stderr, "Error while creating mapper threads\n");
			return -1;
		}
	}

	// Create reducer thread
	((struct reducer_args *)(mr->reducerArgs))->mr = mr;
	mr->outfd = open(outpath, O_WRONLY | O_CREAT | O_TRUNC);
	((struct reducer_args *)(mr->reducerArgs))->nmaps = mr->num_of_threads;
	if(pthread_create(&(mr->reducer_thread), NULL, reducer_fctn_ptr, (void *)mr->reducerArgs)) {
		fprintf(stderr, "Error while creating reducer thread\n");
		return -1;
	}

	return 0;
}

/* Blocks until the entire MapReduce operation is complete */
int
mr_finish(struct map_reduce *mr)
{
	int i;
	
	// Wait for threads	
	for(i = 0; i < mr->num_of_threads; i++) {
		if(pthread_join(mr->mapper_threads[i], NULL) != 0) { // THIS MAY BE BUSY WAITING SO MAYBE CHANGE	
			return -1;
		}
	}
	if(pthread_join(mr->reducer_thread, NULL) != 0) {
		return -1;
	}   

	// Close files	
	close(mr->outfd);
	for(i = 0; i < mr->num_of_threads; i++) {
		close(mr->infd[i]);
	}
		
	if(mr->threadFailed == -1) {
		return -1;
	} else {
		return 0;
	}
}

	

/* Called by the Map function each time it produces a key-value pair */
int
mr_produce(struct map_reduce *mr, int id, const struct kvpair *kv)
{
	int filledBuffer = 0; 

	// Filled buffer check
	pthread_mutex_lock(&(mr->rwBufLock[id]));
	if(sizeof(kv->keysz) + sizeof(kv->valuesz) + kv->keysz + kv->valuesz + mr->bufferOffsets[id] > MR_BUFFER_SIZE) {
		mr->filledBuffer[id] = 1;
	}
	filledBuffer = mr->filledBuffer[id];
	pthread_mutex_unlock(&(mr->rwBufLock[id]));	

	// Condition variable check
	pthread_mutex_lock(&(mr->rwBufLock[id]));
	while(mr->filledBuffer[id] == 1) {
		pthread_cond_wait(&(mr->bufferFull_c[id]), &(mr->rwBufLock[id]));
	}
	pthread_mutex_unlock(&(mr->rwBufLock[id]));

	// Insert kv->keysz
	memcpy(&(mr->buffers[id][mr->bufferOffsets[id]]),&(kv->keysz),sizeof(kv->keysz));
	mr->bufferOffsets[id] += sizeof(kv->keysz);
	
    // Insert kv->key	
	memcpy(&(mr->buffers[id][mr->bufferOffsets[id]]),(kv->key),kv->keysz);
	mr->bufferOffsets[id] += kv->keysz;
	
	// Insert kv->valuesz
	memcpy(&(mr->buffers[id][mr->bufferOffsets[id]]),&(kv->valuesz),sizeof(kv->valuesz));
	mr->bufferOffsets[id] += sizeof(kv->valuesz);
	
	// Insert kv->value
	memcpy(&(mr->buffers[id][mr->bufferOffsets[id]]),(kv->value),kv->valuesz);
	mr->bufferOffsets[id] += kv->valuesz;
	

	// Lock to updates bytes in buffer
	pthread_mutex_lock(&(mr->rwBufLock[id]));	
	mr->bytesInBuffers[id] += sizeof(kv->keysz) + sizeof(kv->valuesz) + kv->keysz + kv->valuesz;
	pthread_mutex_unlock(&(mr->rwBufLock[id]));	

	return 1;
}

/* Called by the Reduce function to consume a key-value pair */
int
mr_consume(struct map_reduce *mr, int id, struct kvpair *kv)
{
	int bytesInBuffer;
	int mapperFinished;

	pthread_mutex_lock(&(mr->rwBufLock[id]));	
	bytesInBuffer = mr->bytesInBuffers[id];                // Get bytes in the buffer
	pthread_mutex_unlock(&(mr->rwBufLock[id]));

	pthread_mutex_lock(&(mr->mapperFinishedLock[id]));	
	mapperFinished = mr->mapperFinished[id];               // Get if mapper thread finished
	pthread_mutex_unlock(&(mr->mapperFinishedLock[id]));	


	while(bytesInBuffer == 0 && mapperFinished==0) {       // Check if no bytes in buffer && mapper not finished
		pthread_mutex_lock(&(mr->rwBufLock[id]));	
		bytesInBuffer = mr->bytesInBuffers[id];

		if(bytesInBuffer == 0 && mr->filledBuffer[id] == 1) {  // Signal a wakeup if buffer was full but now is empty 
			mr->extractOffsets[id] = 0;
			mr->bufferOffsets[id] = 0;
			mr->filledBuffer[id] = 0;
			pthread_cond_signal(&(mr->bufferFull_c[id]));
		}

		pthread_mutex_lock(&(mr->mapperFinishedLock[id]));	
		mapperFinished = mr->mapperFinished[id];
		pthread_mutex_unlock(&(mr->mapperFinishedLock[id]));

		pthread_mutex_unlock(&(mr->rwBufLock[id]));
	}

	// Check if mapper thread finished and no bytes in the buffer
	if(mapperFinished == 1 && bytesInBuffer == 0) {
		return 0;
	}
	
	// Extract kv->keysz
	memcpy(&(kv->keysz), &(mr->buffers[id][mr->extractOffsets[id]]), sizeof(kv->keysz));
	mr->extractOffsets[id] += sizeof(kv->keysz);

	// Extract kv->key
	memcpy((kv->key), &(mr->buffers[id][mr->extractOffsets[id]]), kv->keysz);
	mr->extractOffsets[id] += kv->keysz;

	// Extract kv->valuesz
	memcpy(&(kv->valuesz), &(mr->buffers[id][mr->extractOffsets[id]]), sizeof(kv->valuesz));
	mr->extractOffsets[id] += sizeof(kv->valuesz);

	// Extract kv->value
	memcpy((kv->value), &(mr->buffers[id][mr->extractOffsets[id]]), kv->valuesz);
	mr->extractOffsets[id] += kv->valuesz;

	// Update the number of bytes in the buffer
	pthread_mutex_lock(&(mr->rwBufLock[id]));
	mr->bytesInBuffers[id] -= (sizeof(kv->keysz) + sizeof(kv->valuesz) + kv->keysz + kv->valuesz);
	bytesInBuffer = mr->bytesInBuffers[id];

	if(bytesInBuffer == 0 && mr->filledBuffer[id] == 1) { // Check if it's time to signal a wake up
		mr->extractOffsets[id] = 0;
		mr->bufferOffsets[id] = 0;	
		mr->filledBuffer[id] = 0;
		pthread_cond_signal(&(mr->bufferFull_c[id]));
	}
	
	pthread_mutex_unlock(&(mr->rwBufLock[id]));	

	return 1;
}
